<!DOCTYPE html>
<html>
<head>
    <title>Create Table</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label>Database: </label><input type="text" name="dbname"><br><br>
        <label>Table Name: </label><input type="text" name="table_name"><br><br>
        
        <?php for ($i = 1; $i <= 4; $i++): ?>
            <label>Column name<?php echo $i; ?>: </label><input type="text" name="col<?php echo $i; ?>">
            <label>Data type<?php echo $i; ?>: </label>
            <select id="type<?php echo $i; ?>" name="type<?php echo $i; ?>">
                <option value=""> - </option>
                <option value="varchar(255)">varchar(255)</option>
                <option value="int(255)">int(255)</option>
                <option value="date">date</option>
            </select>
            <label>Constraint<?php echo $i; ?>: </label>
            <select id="constraint<?php echo $i; ?>" name="constraint<?php echo $i; ?>">
                <option value=""> - </option>
                <option value="NOT NULL">NOT NULL</option>
                <option value="UNIQUE">UNIQUE</option>
            </select><br><br>
        <?php endfor; ?>
                       
        <input type="submit" name="submittable" value="Create table">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = $_POST["dbname"]; // Initialize $dbname
        $table_name = $_POST["table_name"];
        $col1 = $_POST["col1"];
        $col2 = $_POST["col2"];
        $col3 = $_POST["col3"];
        $col4 = $_POST["col4"];
        $type1=$_POST["type1"];
        $type2=$_POST["type2"];
        $type3=$_POST["type3"];
        $type4=$_POST["type4"];
        $constraint1=$_POST["constraint1"];
        $constraint2=$_POST["constraint2"];
        $constraint3=$_POST["constraint3"];
        $constraint4=$_POST["constraint4"];

        $conn = new mysqli($servername, $username, $password);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql_query = "USE ".$dbname. "";
        $conn->query($sql_query);
        $sql = "CREATE TABLE" .$table_name." (

        ".$col1." ".$type1." ".$constraint1.",
        ".$col2." ".$type2." ".$constraint2.",
        ".$col3." ".$type3." ".$constraint3.",
        ".$col4." ".$type4." ".$constraint4."
        )";
        echo $sql;
        if ($conn->query($sql) === TRUE) {
            echo "Table created successfully";
        } else {
            echo "Error creating table: " . $conn->error;
        }
       } 
    
    ?>
    <p>
    <a href="index.php">Home </a>|
    <a href="create_database.php">Create database </a>|
    <a href="create_table.php">Create Table </a>|
    <a href="insert_data.php">Insert data </a>|
</p>
</body>
</html>
