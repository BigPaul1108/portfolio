<!DOCTYPE html>
<html>
<head>
    <title>Insert Data</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label>Database: </label><input type="text" name="dbname"><br><br>
        <label>Table Name: </label><input type="text" name="table_name"><br><br>

        <?php for ($i = 1; $i <= 4; $i++): ?>
            <label>Data for Column <?php echo $i; ?>: </label><input type="text" name="data<?php echo $i; ?>"><br><br>
        <?php endfor; ?>

        <input type="submit" name="submitdata" value="Insert Data">
    </form>

    <?php
    $dataarray = [];
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submitdata"])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = $_POST["dbname"];
        $table_name = $_POST["table_name"];
        $data1 = $_POST["data1"];
        $data2= $_POST["data2"];
        $data3 = $_POST["data3"];
        $data4 = $_POST["data4"];


        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql_query = "SELECT COLUMN_NAME FROM information_schema.columns WHERE TABLE_SCHEMA = '$dbname' AND TABLE_NAME = '$table_name'";
        $result = $conn->query($sql_query);
        if ($result && $result->num_rows > 0) {
            $i=0;
            while ($row = $result->fetch_assoc()) {
               $dataarray[$i] = $_POST[$row['COLUMN_NAME']];
                $i++;
            }
        }
$sql = "INSERT INTO $table_name (";
if(isset($dataarray)){
    implode(", ", $dataarray);
}
$sql = rtrim($sql, ', ') . ') VALUES (';    
for ($i = 1; $i <= 4; $i++) {
    $data = $_POST["data$i"];
    $sql .= "'$data', ";
}
$sql = rtrim($sql, ', ') . ')';

        if ($conn->query($sql) === TRUE) {
            echo "Data inserted successfully";
        } else {
            echo "Error inserting data: " . $conn->error;
        }

        $conn->close();
    }
    
    ?>
    <p>
    <a href="index.php">Home </a>|
    <a href="create_database.php">Create database </a>|
    <a href="create_table.php">Create Table </a>|
    <a href="insert_data.php">Insert data </a>|
</p>
</body>
</html>