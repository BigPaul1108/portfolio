<!DOCTYPE html>
<html>
<head>
    <title>Login - Status</title>
</head>
<body>
    <div class="main">
    <form action="create_db.php" method="post">
            <label for="dbname">Database Name:</label>
            <input type="text" name="dbname" id="dbname" required>
            <input type="submit" value="Create Database">
        </form>
       <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        
       
       
        // Create connection
        $conn = new mysqli($servername, $username, $password);
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $dbname = $_POST["dbname"];
            
            // Check if the database already exists
            $checkSql = "SHOW DATABASES LIKE '$dbname'";
            $result = $conn->query($checkSql);

            if ($result->num_rows > 0) {
                echo "Database '$dbname' already exists. Please choose a different name.<br>";
                
            } else {
               
                $createSql = "CREATE DATABASE $dbname";

                if ($conn->query($createSql) === TRUE) {
                    echo "Database '$dbname' created successfully";
              
header('Location: create_table.php?dbname=' . $databaseName);
exit();

                } else {
                    echo "Error creating database: " . $conn->error;
                }
            }
        }
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        echo "Welcome to my database server.";
        $sql_query = "SHOW DATABASES";

        if ($stmt = $conn->query($sql_query)) {
            echo "No of records : " . $stmt->num_rows . "<br>";

            while ($row = $stmt->fetch_assoc()) {
                echo $row['Database'] . "<br>";
            }
        } else {
            echo $connection->error;
        }
    
        $conn->close();
        ?>

<p>
    <a href="index.php">Home </a>|
    <a href="create_database.php">Create database </a>|
    <a href="create_table.php">Create Table </a>|
    <a href="insert_data.php">Insert data </a>|
</p>
    </div>
</body>
</html>
