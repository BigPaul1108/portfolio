<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$connection_string = "";
$username = "";
$password = "";
$f_status = 0; // Set to 0 to indicate the form is not yet submitted

if (isset($_POST['submit'])) {
    $connection_string = $_POST['connection'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $f_status = 1; // Set to 1 to indicate the form has been submitted
}
?>
<div class="main">
    <?php
    if ($f_status === 0) {
    ?>
    
    <form class="form" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label>Database Connection: </label>
                <input type="text" name="connection" required />
        <label>Username: </label>
        <input type="text" name="username" required />

        <label>Password: </label>
        <input type="password" name="password" />
        <button type="submit" name="submit" value="submit">Connect</button>
    </form>
    <?php
    } else {
        $mysqli = new mysqli($connection_string, $username, $password);
        if ($mysqli->connect_errno) {
            if (strpos($mysqli->connect_error, "Access denied") !== false) {
                echo "Incorrect username or password. Please try again.";
            } else {
                echo "Failed to connect to MySQL: " . $mysqli->connect_error;
            }
        } else {
            header('Location: create_db.php');
            exit();
        }
    }
    ?>
   
</div>
</body>
</html>
