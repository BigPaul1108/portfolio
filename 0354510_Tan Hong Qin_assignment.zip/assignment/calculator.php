<!DOCTYPE html>
<html>
<head>
    <title>Calculator</title>
</head>
<body>
    <h1>Calculator</h1>
    <form action="calculator.php" method="post">
        <label for="value1">Value 1:</label>
        <input type="text" name="value1" id="value1" required><br><br>

        <label>Choose an operation:</label><br>
        <input type="radio" name="operation" value="add"> Addition (+)
        <input type="radio" name="operation" value="subtract"> Subtraction (-)
        <input type="radio" name="operation" value="multiply"> Multiplication (*)<br><br>

        <label for="value2">Value 2:</label>
        <input type="text" name="value2" id="value2" required><br><br>

        <button type="submit">Calculate</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $value1 = $_POST["value1"];
        $value2 = $_POST["value2"];
        $operation = $_POST["operation"];
        
        if ($operation == "add") {
            $result = $value1 + $value2;
        } elseif ($operation == "subtract") {
            $result = $value1 - $value2;
        } elseif ($operation == "multiply") {
            $result = $value1 * $value2;
        }

        echo "<h2>Result: $result</h2>";
    }
    ?>
      <p>
    <a href="index.php">Home </a>|
    <a href="calculator.php">Calculator </a>|
    <a href="multi.php">Multiplication Table </a>|
</p>
</body>
<footer>
    <?php include 'footer.php'; ?>
</footer>
</html>
