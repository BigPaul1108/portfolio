<?php

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["name"])) {
    $user_name = $_POST["name"];
    $_SESSION["user_name"] = $user_name;
}

if (isset($_SESSION["user_name"])) {
    $user_name = $_SESSION["user_name"];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<h1>Sussy</h1>
<?php
echo "<h2>Welcome to my page, please enter you name:</h2>";
?>

<?php
    if (isset($user_name)) {
        echo "<div id='welcome-message'>";
        echo "<h2>Welcome, $user_name!</h2>";
        echo "</div>";
    } else {
        echo "<div id='name-form'>";
        echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>";
        echo "<label for='name'>Name: </label>";
        echo "<input type='text' name='name' id='name' required>";
        echo "<button type='submit'>Submit</button>";
        echo "</form>";
        echo "</div>";
    }
    ?>
    <p>
    <a href="index.php">Home </a>|
    <a href="calculator.php">Calculator </a>|
    <a href="multi.php">Multiplication Table </a>|
</p>



</body>
<footer>
    <?php include 'footer.php'; ?>
</footer>
</html>
