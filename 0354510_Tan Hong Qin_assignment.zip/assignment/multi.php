<!DOCTYPE html>
<html>
<head>
    <title>Multiplication Table</title>
</head>
<body>
    <h1>Multiplication Table</h1>
    <form action="multi.php" method="post">
    

        
        <form method="post">
        <label for="table">Select your option:</label>
        <select name="table" id="table">
            <?php
            for ($i = 1; $i <= 12; $i++) {
                echo "<option value=\"$i\">$i</option>";
            }
            ?>
        </select>
        <input type="submit" name="generate" value="Generate Table">
    </form>


    <?php
    if (isset($_POST['generate'])) {
        $selectedTable = $_POST['table'];
        echo "<h3>Multiplication Table for $selectedTable</h3>";
        echo "<table border='1'>";
        for ($i = 1; $i <= 12; $i++) {
            $result = $selectedTable * $i;
            echo "<tr><td>$selectedTable x $i</td><td>= $result</td></tr>";
        }
        echo "</table>";
    }
    ?>
    
      <p>
    <a href="index.php">Home </a>|
    <a href="calculator.php">Calculator </a>|
    <a href="multi.php">Multiplication Table </a>|
</p>
</body>
<footer>
    <?php include 'footer.php'; ?>
</footer>
</html>
