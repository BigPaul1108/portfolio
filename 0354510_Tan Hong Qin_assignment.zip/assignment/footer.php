<footer>
Copyright &copy; <?php echo date("Y"); ?> Sussy

</footer>
